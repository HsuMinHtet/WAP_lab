console.log(x);
function foo() {
    console.log('foo...');
}
