const res = (function(){
    var x = 10;
    console.log(x);
    return 'hello';
})();
console.log(res);



// function foo() {
//     console.log(x);
// }
// foo();


// {
//     let x = 10;
//     console.log(x);
// }

// function foo(){
//     console.log(x);
// }
// foo();