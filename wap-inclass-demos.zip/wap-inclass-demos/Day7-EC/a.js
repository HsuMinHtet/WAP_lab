let x = 10;
