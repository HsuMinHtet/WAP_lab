const fs = require('fs'); //built-in module/3rd party module - module name
const math = require('./math'); // your own module - relative path

console.log(math);