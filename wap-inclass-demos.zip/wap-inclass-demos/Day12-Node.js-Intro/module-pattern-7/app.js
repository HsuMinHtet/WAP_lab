// const person = require('./person');
// 
// {
//     person: class Person
// }

// console.log(new person.person().getFullName());


// const {person} = require('./person');
// console.log(new person().getFullName());

// const person = {
//     firstname: 'John',
//     lastname: 'Smith'
// }

// // const firstname = person.firstname;
// // const lastname = person.lastname;

// const {firstname, lastname} = person;

const result = require('./person');
console.log(result);