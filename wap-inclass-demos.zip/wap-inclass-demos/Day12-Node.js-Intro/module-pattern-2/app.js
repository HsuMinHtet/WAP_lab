const pattern = require('./pattern');

console.log(pattern);