// module.exports = {}

module.exports.getName = function () {
    console.log('Josh Edward');
};

// exports.getName = function () {
//     console.log('Josh Edward');
// };

//return module.exports

