// const result = require('./pattern');

// console.log(result);
// result.getName();

// const {getName} = require('./pattern');
// getName();

const getName = require('./pattern').getName;
getName();