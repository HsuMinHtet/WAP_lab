const result = require('./pattern');

console.log('result: ', result);
// console.log(fruit, country, zipCode);