
var fruit = ['banana', 'strawberry'];
let country = 'US';
const zipCode = 52556;

console.log(fruit, country, zipCode);
console.log('Pattern.js is being executed...');

