// module.exports = {}

module.exports = function () {
    console.log('Josh Edward');
};

//return module.exports

