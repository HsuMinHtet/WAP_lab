const result = require('./pattern');

console.log(result);