const sayHi = function(){
    console.log('Hi');
}
// by default, module.exports = {}
module.exports.sayHi = sayHi;