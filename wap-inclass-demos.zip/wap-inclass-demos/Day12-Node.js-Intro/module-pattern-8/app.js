const math = require('./math');
console.log(math);
math.add(1,3)