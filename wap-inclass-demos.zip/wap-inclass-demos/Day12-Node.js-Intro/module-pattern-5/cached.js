const person = require('./person');
console.log('---inside cached.js----', person.getFullName());