const Person = require('./person');
console.log('---inside cached.js----', new Person().getFullName());