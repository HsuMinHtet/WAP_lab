const john = new User('John');
const edward = new john.constructor('Edward');

console.log(edward);