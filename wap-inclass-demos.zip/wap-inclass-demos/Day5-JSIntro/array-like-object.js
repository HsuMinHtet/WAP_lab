const obj = {
    0: 'a',
    1: 'b',
    2: 'c',
    length: 3
}

for(let i = 0; i < obj.length; i++){
    console.log(obj[i]);
}