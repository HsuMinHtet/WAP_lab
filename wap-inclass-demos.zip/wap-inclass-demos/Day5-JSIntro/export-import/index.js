import {add, substract} from './math.js';
console.log(add(4,5));
console.log(substract(6,8));

import greeting from './utility.js';
console.log(greeting('Josh'));
