function greeting(name){
    return `Hello, ${name}`;
}

export default greeting;
export const foo = () => {};