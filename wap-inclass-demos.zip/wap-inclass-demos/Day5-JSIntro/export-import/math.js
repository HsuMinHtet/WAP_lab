// export const add = (a, b) => a + b;
// export const substract = (a, b) => a - b;

const add = (a, b) => a + b;
const substract = (a, b) => a - b;

export {add, substract};
