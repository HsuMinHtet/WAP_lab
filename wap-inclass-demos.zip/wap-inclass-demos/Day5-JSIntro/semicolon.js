alert('hello')
[1,2,3,4].forEach(elem => console.log('element: ', elem))
