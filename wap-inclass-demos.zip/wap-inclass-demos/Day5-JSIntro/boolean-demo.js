// fasly value:  false, 0, 0.0, NaN, empty String(""), null, and undefined
const result = {};

if(result){
    console.log('inside true...');
} else {
    console.log('inside false*****');
}