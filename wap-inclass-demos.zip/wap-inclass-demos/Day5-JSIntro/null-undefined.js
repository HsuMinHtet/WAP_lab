let i;
console.log(i); //undefined

let j = null;
console.log(j);