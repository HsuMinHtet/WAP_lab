const fruit = [];
// stack FILO LIFO use methods: push, pop
// fruit.push('apple');
// fruit.push('banana');
// fruit.push('pear');
// console.log(fruit);
// console.log(fruit.pop());
// console.log(fruit);


// Queue FIFO //use methods: push, 
fruit.push('apple');
fruit.push('banana');
fruit.push('pear');
console.log(fruit);
console.log(fruit.shift());
console.log(fruit); //['banana', 'pear']
console.log(fruit.unshift('strawberry'));
console.log(fruit);



// fruit[3] = 123;
// fruit[4] = true;
// fruit[5] = {x:1, y:2}
// fruit[6] = [1, 2,4];

// console.log(fruit);
// console.log(fruit[0]);

// const countries = new Array();
// countries[0] = 'US';

// console.log(countries);

