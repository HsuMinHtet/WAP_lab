var x1 = 100;
let y2 = 'a2222';
const z3 = 114444;
console.log(x1, y2, z3);