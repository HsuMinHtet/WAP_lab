// const username = 'CS472';
// // username = 'abc';

// let m = 10;
// m = 'abc';
// console.log(m);

// var j = 10;
// j = 'hello';
// console.log(j);


// // for(var i = 0; i < 10; i++){
// //     console.log(i);
// // }
// // console.log('outside for loop: ', i);

// let i = 100;
// console.log(typeof i);
// i = 'hello';
// console.log('-----');
// console.log(typeof i);



const person = {firstname: 'John', lastname: 'Smith'};
// person = 10;
person.firstname = 'Yoyo';
console.log(person);


