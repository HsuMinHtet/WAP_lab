const i = 10;
const j = 19.89;

console.log(typeof i); 
console.log(typeof j);

let credits = 5 + 4 + (2 * 3);
console.log(credits);
console.log('3' + 2);
console.log('5' * 6);
console.log('5tt' * 6); //NaN
console.log(parseInt('r5tt') * 6);
