console.log(2 > 3);
console.log('9' > 7);
console.log(2 == 2.0);
console.log(2 == '2.0'); // == only compare value
console.log('******')
console.log(2 === '2.0'); // === compare value & type

console.log('a' == 7); // 'a' -> NaN, always false

console.log('a' === 'a');