setTimeout(() => console.log('timeout'), 5000);
console.log('End');
// console.log(window);
console.log(global);
console.log(globalThis === global);
// var i = 10;

