const fs = require('fs');

fs.readFile('hello.txt', () => {
    console.log('readFile....');
});
setTimeout(() => console.log('timeout'), 0);
setImmediate(() => console.log('Immediate'));
