class Animal {
    private String country = 'US';

    public Animal(name){
        this.name = name;
        this.speed = 0;
    }

}

Animal a = new Animal();