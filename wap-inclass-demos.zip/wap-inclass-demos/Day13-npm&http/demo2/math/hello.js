exports.add = function(num1, num2){
    return num1 + num2;
}

exports.substract = function(num1, num2){
    return num1 - num2;
}