const math = require('./math'); //folder
console.log(math);