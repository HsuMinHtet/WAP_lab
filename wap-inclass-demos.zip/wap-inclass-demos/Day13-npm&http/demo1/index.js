const moment = require('moment');
const result = moment().format("LLLL");
console.log(result);