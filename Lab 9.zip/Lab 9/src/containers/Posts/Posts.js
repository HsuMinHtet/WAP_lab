import { useEffect, useState } from "react";
import Post from "../../components/Post/Post";
import axios from "axios";
import PostDetails from "../../components/PostDetails/PostDetails";
import { Link } from "react-router-dom";

const Posts = (props) => {
  const [flag, setFlag] = useState(true);
  const [postsState, setPostsState] = useState([
    { id: 1, title: "Business", author: "Timmy" },
    { id: 2, title: "Education", author: "Jhon" },
    { id: 3, title: "Science", author: "Rose" },
  ]);

  const fetchPosts = () => {
    axios
      .get("http://localhost:8080/posts/")
      .then((response) => {
        setPostsState(response.data);
      })
      .catch((error) => {
        console.log(error.message);
      });
  };

  //fetchPosts();
  useEffect(() => {
    fetchPosts();
  }, []);

  const postList = postsState.map((post) => {
    return (
      <Link to={`${post.id}`} key={post.id}>
        <Post
          title={post.title}
          author={post.author}
          id={post.id}
          key={post.id}
          setSelected={() => {
            props.setSelected(post.id);
          }}
        />
      </Link>
    );
  });
  return (
    <div className="Post">
      {postList}
      <PostDetails />
    </div>
  );
};

export default Posts;

// const memorizedComponent = useMemo(() => {
//   console.log("Rendering PostList");
//   const postList = props.posts.map((post) => {
//     return (
//       <Post
//         title={post.title}
//         author={post.author}
//         id={post.id}
//         key={post.id}
//         setSelected={() => {
//           props.setSelected(post.id);
//         }}
//       />
//     );
//   });
//   return postList;
// }, Post);
// return memorizedComponent;
// };

// export default Posts;
