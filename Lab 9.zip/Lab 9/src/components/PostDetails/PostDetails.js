import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import Dashboard from "../../containers/DashBoard/Dashboard";
import axios from "axios";
import Comment from "../Comment/Comment";
import { useNavigate, useParams } from "react-router";
import "./PostDetails.css";
import { ThemeColorContext } from "../store/ThemeColor";

const PostDetails = (props) => {
  const params = useParams();
  const navigate = useNavigate();
  const [postDetail, setPostDetail] = useState([]);
  const [value, setValue] = useState(0); // click button , this will change the value for useMemo example
  const textField = useRef();
  const [themeColorState, setThemeColorState] = useState({ color: "red" });

  useEffect(() => {
    if (params.id) {
      axios
        .get("http://localhost:8080/posts/" + params.id)
        .then((response) => {
          setPostDetail(response.data);
          console.log(response.data);
        })
        .catch((err) => console.log(err.message));
    }
  }, [params.id]);

  const deleteButtonClicked = (id) => {
    axios
      .delete("http://localhost:8080/posts/" + id)
      .then((response) => {
        //fetchPosts();
        navigate("/");
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const space = <Fragment>&nbsp;&nbsp;</Fragment>;

  let postDetailDisplay = null;
  if (params.id) {
    postDetailDisplay = (
      <ThemeColorContext.Provider value={themeColorState}>
        <div className="PostDetail">
          <div>
            <h1>Post Details</h1>
          </div>
          <h3>ID: {params.id}</h3>
          <h3>Title: {postDetail.title}</h3>
          <h3>Author: {postDetail.author}</h3>

          <div style={{ textAlign: "left" }}>
            {space} Comments <br />
            {postDetail.commentList != null
              ? postDetail.commentList.map((c) => {
                  return <Comment comment={c.name} key={c.id} />;
                })
              : null}
          </div>

          <div>
            <input
              type="button"
              value="delete"
              onClick={() => deleteButtonClicked(params.id)}
            />
            <input type="button" value="edit" onClick={props.editPost} />
          </div>
        </div>
      </ThemeColorContext.Provider>
    );
  }
  return postDetailDisplay;
};

export default PostDetails;
