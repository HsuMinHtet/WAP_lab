const Post = (props) => {
  return (
    <div className="Content">
      <div className="Post">
        <h3>ID: {props.id}</h3>
        <h3>Title: {props.title}</h3>
        <h3>Author: {props.author}</h3>
      </div>
    </div>
  );
};

export default Post;
